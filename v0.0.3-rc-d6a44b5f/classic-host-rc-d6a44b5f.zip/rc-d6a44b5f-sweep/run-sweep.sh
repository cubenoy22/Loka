#!/usr/bin/env bash
# RC d6a44b5f Classic scenario sweep driver.
# Untracked evidence helper: lives under build/, never committed.
set -uo pipefail

PROJECT_DIR="/mnt/c/Users/cuben/source/repos/Loka"
SWEEP_DIR="$PROJECT_DIR/build/rc-d6a44b5f-sweep"
RESULTS="$SWEEP_DIR/results.tsv"
RUNNER="$PROJECT_DIR/tests/toolbox/run-scenario.sh"

mkdir -p "$SWEEP_DIR"

# Wait until no real MAME process is running. pgrep would otherwise match this
# script and its bash wrapper, so drop anything that is clearly not the emulator.
wait_for_mame_free() {
  local waited=0
  while true; do
    local hits
    hits="$(pgrep -af -i mame 2>/dev/null | grep -viE 'run-sweep|run-scenario|pgrep|bash -c|claude|shell-snapshot' || true)"
    if [ -z "$hits" ]; then
      return 0
    fi
    if [ "$waited" -ge 900 ]; then
      echo "TIMEOUT waiting for MAME to exit; still running:" >&2
      echo "$hits" >&2
      return 1
    fi
    sleep 10
    waited=$((waited + 10))
  done
}

run_cell() {
  local example="$1" scenario="$2" mode="${3:-plain}"
  local log
  if [ "$mode" = "golden" ]; then
    log="$SWEEP_DIR/${example}-${scenario}.update-golden.log"
  else
    log="$SWEEP_DIR/${example}-${scenario}.log"
  fi

  if ! wait_for_mame_free; then
    echo -e "${example}\t${scenario}\t${mode}\tBLOCKED\t${log}" >>"$RESULTS"
    return 1
  fi

  echo "=== $(date -Is) START $example $scenario ($mode) ===" | tee -a "$SWEEP_DIR/sweep.log"
  local start=$SECONDS
  # MAME reads stdin; without </dev/null it swallows the caller's registry feed.
  if [ "$mode" = "golden" ]; then
    "$RUNNER" "$example" "$scenario" --update-golden >"$log" 2>&1 </dev/null
  else
    "$RUNNER" "$example" "$scenario" >"$log" 2>&1 </dev/null
  fi
  local rc=$?
  local elapsed=$((SECONDS - start))
  echo "EXIT=$rc ELAPSED=${elapsed}s" >>"$log"

  local verdict=PASS
  [ "$rc" -ne 0 ] && verdict=FAIL
  echo -e "${example}\t${scenario}\t${mode}\t${verdict}\t${log}\t${elapsed}s" >>"$RESULTS"
  echo "=== $(date -Is) END $example $scenario ($mode) $verdict ${elapsed}s ===" | tee -a "$SWEEP_DIR/sweep.log"
  return $rc
}

: >"$RESULTS"

# The two new cells need a golden recorded first; only the later plain run counts.
NEW_CELLS=("helloworld bmi-roundtrip" "minesweeper seeded-reveal")
for cell in "${NEW_CELLS[@]}"; do
  set -- $cell
  golden="$PROJECT_DIR/build/mame-scenario/golden/$1/$2.png"
  if [ -f "$golden" ]; then
    echo "golden already present for $1 $2, skipping record pass" | tee -a "$SWEEP_DIR/sweep.log"
    continue
  fi
  if ! run_cell "$1" "$2" golden; then
    echo "STOPPING: golden record failed for $1 $2" | tee -a "$SWEEP_DIR/sweep.log"
    exit 1
  fi
done

# Full registry sweep, in registry order, plain verify only.
# Read the whole registry up front so no child process can consume the feed.
mapfile -t CELLS <"$PROJECT_DIR/tests/scenarios/scenarios.txt"
echo "registry cells to run: ${#CELLS[@]}" | tee -a "$SWEEP_DIR/sweep.log"
for cell in "${CELLS[@]}"; do
  [ -z "$cell" ] && continue
  set -- $cell
  if ! run_cell "$1" "$2" plain; then
    echo "STOPPING: red cell $1 $2" | tee -a "$SWEEP_DIR/sweep.log"
    exit 1
  fi
done

echo "SWEEP COMPLETE: all cells green" | tee -a "$SWEEP_DIR/sweep.log"
