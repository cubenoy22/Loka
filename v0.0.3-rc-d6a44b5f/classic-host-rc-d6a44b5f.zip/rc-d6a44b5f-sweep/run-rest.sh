#!/usr/bin/env bash
set -uo pipefail
P="/mnt/c/Users/cuben/source/repos/Loka"
S="$P/build/rc-d6a44b5f-sweep"
R="$S/results-rest.tsv"
: >"$R"
wait_free(){ local w=0; while true; do h="$(pgrep -af -i mame 2>/dev/null | grep -viE 'run-rest|run-sweep|run-scenario|pgrep|bash -c|claude|shell-snapshot' || true)"; [ -z "$h" ] && return 0; [ $w -ge 900 ] && return 1; sleep 10; w=$((w+10)); done; }
CELLS=(
"helloworld toggle-action-probe" "helloworld bmi-roundtrip"
"tutorial startup" "tutorial increment-summary-toggle"
"minesweeper startup" "minesweeper new-game-twice" "minesweeper seeded-reveal"
"floppybird startup" "floppybird fixed-step-flaps"
)
for c in "${CELLS[@]}"; do
  set -- $c; e="$1"; s="$2"; log="$S/${e}-${s}.log"
  wait_free || { echo -e "$e\t$s\tBLOCKED\t$log" >>"$R"; continue; }
  st=$SECONDS
  "$P/tests/toolbox/run-scenario.sh" "$e" "$s" >"$log" 2>&1 </dev/null; rc=$?
  el=$((SECONDS-st)); echo "EXIT=$rc ELAPSED=${el}s" >>"$log"
  v=PASS; [ $rc -ne 0 ] && v=FAIL
  echo -e "$e\t$s\t$v\t$log\t${el}s" >>"$R"
  echo "$(date -Is) $e $s $v ${el}s"
done
echo "REST SWEEP DONE"
