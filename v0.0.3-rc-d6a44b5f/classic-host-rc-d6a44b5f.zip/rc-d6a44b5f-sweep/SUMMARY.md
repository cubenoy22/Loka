# v0.0.3 RC d6a44b5f — WSL host + Classic (maciix) verification

RC `d6a44b5f995641007905a876e0d3ddf1cdaf202d` = main `c97df048` + one release-only
commit adding `scripts/release/release-v0.0.3-classic.txt` (untracked-path
allowlist). `git diff c97df048 origin/release/0.0.3 --stat` shows that single
15-line file; there is no code delta, so binaries built at main are exact-RC
binaries.

## Host (WSL, testing preset)

- ctest: **399/399 passed** (host-ctest.log). Note: a first run against a stale
  build tree reported 378/378 — discarded; the tree was wiped and reconfigured.
- `tools/ci/check_test_asserts.py`: clean (228 files, 126 load-bearing names).

## Classic builds (clean rebuilds)

- retro68-68k-release: 193/193 targets, exit 0 (68k-build.log). All 6 release
  68K bins + ASSETS.LRP present, mtimes newer than newest source.
- retro68-ppc-release: 84/84 targets, exit 0, no warnings (ppc-build.log).
  Build-verified only, per the matrix.

## Classic scenario sweep — 17/17 PASS (MAME maciix)

All 17 registry cells run via `tests/toolbox/run-scenario.sh`; per-cell logs in
this directory. The two #400 cells (`helloworld bmi-roundtrip`,
`minesweeper seeded-reveal`) were first-time recordings: golden + `.mame-machine`
sidecar recorded once (`*.update-golden.log`), then verified plain — the plain
runs are the evidence.

Initial sweep was 15/17: `helloworld startup` and `helloworld
toggle-action-probe` differed by exactly 2 pixels at (211,51)–(212,51) — the
Finder disk-usage readout above the app window, shifted because #400 changed
the vehicle binary size while the goldens predated it (recorded at 634f1a72).
App-window pixels were identical and every audit step succeeded; the
freshly-recorded `bmi-roundtrip` passing on the same vehicle is the control.
Both goldens were re-recorded from the RC binary (`*.rerecord.log`) and
re-verified plain (`*.verify2.log`): **PASS**. Rail hardening for the
desktop-chrome class is tracked as #408.

## Cross-references

- macOS rail (tahoe): 14/17 PASS at the same RC; the 3 scrapbook refusal cells
  are a macOS-runner staging gap, not a product regression — #407. The refusal
  family is witnessed green on this Classic rail at the same RC (cells 3, 5, 7).
- Win32 rail: 17/17 at PR #389 head `4c7ee2db` (base `ca6fa55a`); the delta to
  the RC is #403 (docs + debug-rig scripts only), which touches no Win32 source,
  so those runs are binary-equivalent RC evidence.

Verification by Opus (sweep) and Fable (golden re-baseline + this record), 2026-08-17.
