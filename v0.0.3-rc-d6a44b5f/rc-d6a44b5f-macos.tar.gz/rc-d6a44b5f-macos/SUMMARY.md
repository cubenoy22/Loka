# Loka v0.0.3 RC macOS scenario rail — tahoe

SHA: d6a44b5f995641007905a876e0d3ddf1cdaf202d  (Add the v0.0.3 Classic release-asset allowlist)
Rig: tahoe (macOS 26.6.1, x86_64)
Built: cmake --preset macos-debug ; cmake --build --preset macos-scenarios
Goldens: none existed on this rig; every cell recorded with --update-golden then re-run in plain verify mode.

| example | scenario | record | verify |
|---|---|---|---|
| scrapbook | startup | RECORDED | PASS |
| scrapbook | open-first-page | RECORDED | PASS |
| scrapbook | open-first-page-refused | RECORD-FAIL | FAIL |
| scrapbook | flip-forward-back | RECORDED | PASS |
| scrapbook | refused-flip-keeps-page | RECORD-FAIL | FAIL |
| scrapbook | open-text-page | RECORDED | PASS |
| scrapbook | open-text-page-refused | RECORD-FAIL | FAIL |
| helloworld | startup | already-recorded | PASS |
| helloworld | toggle-action-probe | RECORDED | PASS |
| helloworld | bmi-roundtrip | RECORDED | PASS |
| tutorial | startup | RECORDED | PASS |
| tutorial | increment-summary-toggle | RECORDED | PASS |
| minesweeper | startup | RECORDED | PASS |
| minesweeper | new-game-twice | RECORDED | PASS |
| minesweeper | seeded-reveal | RECORDED | PASS |
| floppybird | startup | RECORDED | PASS |
| floppybird | fixed-step-flaps | RECORDED | PASS |
